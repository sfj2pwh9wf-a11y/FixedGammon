# Adikus Backgammon Analyzer — Python 3.13 build

The failed deployment used Python 3.14.7. The gnubg-nn 1.1.0a8 Linux wheels
support CPython 3.10–3.13, not 3.14.

For Streamlit Community Cloud, redeploy the app and choose Python 3.13 under
Advanced settings. Streamlit says changing Python after deployment requires
deleting and redeploying the app.

Replace app.py and requirements.txt with these files. runtime.txt is included
as an explicit Python-version note, but the Community Cloud deployment dialog
is authoritative.
