import streamlit as st
from PIL import Image
import numpy as np
import cv2
import gnubg_nn

X_NORM = [0.055, 0.132, 0.207, 0.280, 0.360, 0.433, 0.560, 0.637, 0.715, 0.789, 0.865, 0.939]
TOP_Y0 = 0.254
BOTTOM_Y0 = 0.800
STACK_DY = 0.034
TL = [24, 23, 22, 21, 20, 19]
TR = [13, 14, 15, 16, 17, 18]
BL = [12, 11, 10, 9, 8, 7]
BR = [6, 5, 4, 3, 2, 1]

def classify(bgr):
    b, g, r = map(float, bgr)
    mean = (b + g + r) / 3
    spread = max(b, g, r) - min(b, g, r)
    if mean > 180 and spread < 22: return "W"
    if mean < 45 and spread < 22: return "B"
    return "."

def stack(img, x, y0, direction, max_n=15):
    h, w = img.shape[:2]
    step = STACK_DY * h
    vals = []
    for i in range(max_n):
        y = int(round(y0 + direction * i * step))
        if y < 0 or y >= h: break
        vals.append(classify(img[y, x]))
    color = None
    n = 0
    for v in vals:
        if v == ".": break
        if color is None: color = v
        if v != color: break
        n += 1
    return color or ".", n

def detect_board(image):
    rgb = np.asarray(image.convert("RGB"))
    img = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    h, w = img.shape[:2]
    xs = [int(round(x*w)) for x in X_NORM]
    white, black = [0]*25, [0]*25
    def put(p, c, n):
        if c == "W": white[p] = n
        elif c == "B": black[p] = n
    for i, x in enumerate(xs[:6]):
        c,n = stack(img,x,TOP_Y0*h,+1); put(TL[i],c,n)
    for i, x in enumerate(xs[6:]):
        c,n = stack(img,x,TOP_Y0*h,+1); put(TR[i],c,n)
    for i, x in enumerate(xs[:6]):
        c,n = stack(img,x,BOTTOM_Y0*h,-1); put(BL[i],c,n)
    for i, x in enumerate(xs[6:]):
        c,n = stack(img,x,BOTTOM_Y0*h,-1); put(BR[i],c,n)
    return white, black

def validate(w,b):
    errors = []
    if sum(w) > 15: errors.append("White checker count exceeds 15.")
    if sum(b) > 15: errors.append("Black checker count exceeds 15.")
    for p in range(1,25):
        if w[p] and b[p]: errors.append(f"Point {p} was detected with both colors.")
    return errors

def move_text(m):
    if not m: return "No legal move found."
    return ", ".join(f"{'bar' if a==0 else a}/{'off' if z==0 else z}" for a,z in m)

st.set_page_config(page_title="Backgammon Analyzer", page_icon="🎲", layout="centered")
st.title("🎲 Backgammon Analyzer")
st.caption("Upload an Adikus screenshot → verify → find the strongest move")

file = st.file_uploader("Upload your latest Adikus screenshot", type=["png","jpg","jpeg"])
if file:
    image = Image.open(file).convert("RGB")
    w,b = detect_board(image)
    errors = validate(w,b)
    st.image(image, use_container_width=True)
    if errors:
        st.error("Position could not be verified — I will not guess.")
        for e in errors: st.write("• " + e)
        st.stop()

    st.success("✓ Position passed basic validation")
    st.subheader("Dice")
    c1,c2 = st.columns(2)
    with c1: d1 = st.number_input("Die 1", 1, 6, 1, 1)
    with c2: d2 = st.number_input("Die 2", 1, 6, 1, 1)
    st.caption("The board is read fresh from every screenshot. Enter only the two dice.")
    if st.button("Find strongest move", type="primary", use_container_width=True):
        try:
            board = [w, b]

            # Use the neural-net move search. Different gnubg-nn builds have
            # exposed slightly different keyword signatures, so use a small
            # compatibility fallback rather than crashing the app.
            try:
                move = gnubg_nn.best_move(board, int(d1), int(d2), n=2, s="X")
            except TypeError:
                try:
                    move = gnubg_nn.best_move(board, int(d1), int(d2), s="X")
                except TypeError:
                    move = gnubg_nn.best_move(board, int(d1), int(d2))

            # The public API returns [(from,to), ...] when the optional flags
            # are false. Normalize defensively in case a build returns a flat
            # sequence.
            if move and isinstance(move[0], int):
                move = list(zip(move[0::2], move[1::2]))

            st.success("BEST MOVE")
            st.markdown(f"## {move_text(move)}")
        except Exception as e:
            st.error("The engine could not analyze this position.")
            st.code(str(e))
